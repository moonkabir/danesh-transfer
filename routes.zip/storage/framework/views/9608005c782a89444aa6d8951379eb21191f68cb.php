<footer class="main-footer text-center">
    <strong>Copyright &copy; 2014-<?php echo e(date("Y")); ?> <a href="/">Danesh transfer</a>.</strong>All rights reserved.
</footer>
<?php /**PATH E:\Work\PencilBox\danesh transfer\danesh-transfer\resources\views/user/includes/footer.blade.php ENDPATH**/ ?>