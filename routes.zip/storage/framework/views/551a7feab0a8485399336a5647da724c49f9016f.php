    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Brand Logo -->
        <a href="index3.html" class="brand-link">
        
        <span class="brand-text font-weight-light">Danesh Transfer</span>
        </a>

        <!-- Sidebar -->
        <div class="sidebar">
            <!-- Sidebar user panel (optional) -->
            <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                <div class="image">
                
                </div>
                <div class="info">
                    <a href="#" class="d-block"><?php echo e(Auth ::user()->name); ?></a>
                </div>
            </div>

            <!-- SidebarSearch Form -->
            <div class="form-inline">
                <div class="input-group" data-widget="sidebar-search">
                <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
                <div class="input-group-append">
                    <button class="btn btn-sidebar">
                    <i class="fas fa-search fa-fw"></i>
                    </button>
                </div>
                </div>
            </div>

        <!-- Sidebar Menu -->
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                    <li class="nav-item menu-open">
                        <a href="<?php echo e(url('/admin/dashboard')); ?>" class="nav-link <?php echo $__env->yieldContent('dashboard_menu_active'); ?>">
                            <i class="nav-icon fas fa-tachometer-alt"></i><p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item menu-open">
                        <a href="<?php echo e(url('/admin/users')); ?>" class="nav-link <?php echo $__env->yieldContent('users_menu_active'); ?>">
                            <i class="nav-icon fa fa-users"></i><p>Users</p>
                        </a>
                    </li>
                    <li class="nav-item menu-open">
                        <a href="<?php echo e(url('/admin/country')); ?>" class="nav-link <?php echo $__env->yieldContent('country_menu_active'); ?>">
                            <i class="fas fa-flag"></i></i> <p>Country</p>
                        </a>
                    </li>
                    <li class="nav-item menu-open">
                        <a href="<?php echo e(url('/admin/currency')); ?>" class="nav-link <?php echo $__env->yieldContent('currency_menu_active'); ?>">
                            <i class="fas fa-dollar-sign"></i> <p>Currency</p>
                        </a>
                    </li>
                </ul>
            </nav>
        <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
    </aside>
<?php /**PATH E:\Work\PencilBox\danesh transfer\danesh-transfer\resources\views/admin/includes/sidebar.blade.php ENDPATH**/ ?>