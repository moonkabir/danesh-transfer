<?php $__env->startSection('transfer_menu_active','active'); ?>
<?php $__env->startSection('receiver_menu_active','active'); ?>
<?php $__env->startSection('transfer_menu_open','menu-open'); ?>
<?php $__env->startSection('body'); ?>
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <?php if(Session::get('message')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong><?php echo e(Session::get('message')); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">All Receiver</h3>
                            <a href="<?php echo e(url('user/create-receiver/')); ?>" class="float-right">Add Receiver</a>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>#ID</th>
                                        <th>First Name</th>
                                        <th>Middle Name</th>
                                        <th>Last Name</th>
                                        <th>Phone Number</th>
                                        <th>Country</th>
                                        <th>City/Town</th>
                                        <th>Street</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $receivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receiver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($receiver->id); ?></td>
                                        <td><?php echo e($receiver->first_name); ?></td>
                                        <td><?php echo e($receiver->middle_name); ?></td>
                                        <td><?php echo e($receiver->last_name); ?></td>
                                        <td><?php echo e($receiver->phone_number); ?></td>
                                        <td><?php echo e($receiver->country); ?></td>
                                        <td><?php echo e($receiver->city); ?></td>
                                        <td><?php echo e($receiver->street_name); ?></td>
                                        <td>
                                            <a href="receiver-update/<?php echo e($receiver->id); ?>"><i class="fas fa-edit"></i></a>&nbsp|
                                            <a href="receiver-delete/<?php echo e($receiver->id); ?>"><i class="fas fa-trash-alt"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>#ID</th>
                                        <th>First Name</th>
                                        <th>Middle Name</th>
                                        <th>Last Name</th>
                                        <th>Phone Number</th>
                                        <th>Country</th>
                                        <th>City/Town</th>
                                        <th>Street</th>
                                        <th>Action</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\PencilBox\danesh transfer\danesh-transfer\resources\views/user/transfer/receiver/all-receiver.blade.php ENDPATH**/ ?>