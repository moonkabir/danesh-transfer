<?php $__env->startSection('country_menu_active','active'); ?>
<?php $__env->startSection('transfer_menu_open','menu-open'); ?>
<?php $__env->startSection('body'); ?>
<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <!-- left column -->
            <div class="offset-md-3 col-md-6">
                <!-- general form elements -->
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="text-center">Update Country</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form action="<?php echo e(url('/admin/country-update/'.$country[0]->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <div class="card-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Country name</label>
                                <input type="text" class="form-control" name="country_name" id="country_country" value="<?php echo e($country[0]->name); ?>">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Country Code</label>
                                <input type="text" class="form-control" name="country_code" id="country_code" value="<?php echo e($country[0]->code); ?>">
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
                <!-- /.card -->
            </div>
            <!--/.col (left) -->
        </div>
        <!-- /.row -->
    </div><!-- /.container-fluid -->
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\PencilBox\danesh transfer\danesh-transfer\resources\views/admin/country/edit-country.blade.php ENDPATH**/ ?>