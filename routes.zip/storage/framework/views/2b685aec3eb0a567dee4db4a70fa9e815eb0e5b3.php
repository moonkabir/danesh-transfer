<?php $__env->startSection('currency_menu_active','active'); ?>
<?php $__env->startSection('body'); ?>
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <?php if(Session::get('message')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong><?php echo e(Session::get('message')); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">All Currency</h3>
                            <a href="<?php echo e(url('admin/create-currency/')); ?>" class="float-right">Add Currency</a>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>#ID</th>
                                        <th>Currency Name</th>
                                        <th>Currency Code</th>
                                        <th>Currency Flag</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $all_currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($currency->id); ?></td>
                                        <td><?php echo e($currency->name); ?></td>
                                        <td><?php echo e($currency->code); ?></td>
                                        <td>
                                            <img id="currency_flag_img" src="<?php echo e(asset('assets/admin/images/flag/\/').$currency->flag); ?>" width="50" alt=""/>
                                        </td>
                                        <td>
                                            <a href="currency-update/<?php echo e($currency->id); ?>"><i class="fas fa-edit"></i></a>&nbsp|
                                            <a href="currency-delete/<?php echo e($currency->id); ?>"><i class="fas fa-trash-alt"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>#ID</th>
                                        <th>Currency Name</th>
                                        <th>Currency Code</th>
                                        <th>Currency Flag</th>
                                        <th>Action</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\PencilBox\danesh transfer\danesh-transfer\resources\views/admin/currency/all-currency.blade.php ENDPATH**/ ?>