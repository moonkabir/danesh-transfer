<footer class="main-footer text-center">
    <strong>Copyright &copy; 2014-{{date("Y");}} <a href="/">Danesh transfer</a>.</strong>All rights reserved.
</footer>
